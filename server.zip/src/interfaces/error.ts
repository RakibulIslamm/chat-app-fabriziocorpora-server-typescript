export type GenericErrorMessageType = {
  path: string | number;
  message: string;
};
